def Hello_World():
  print("Hello World")

Hello_World


